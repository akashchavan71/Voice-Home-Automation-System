//
//  HomeViewController.swift
//  Siri
//
//  Created by Sudeep Gokarn on 12/4/19.
//  Copyright © 2019 Sahand Edrisian. All rights reserved.
//
import UIKit
import Foundation

class HomeViewController: UIViewController, UITextFieldDelegate {
    
    @IBOutlet weak var textFieldIPAddress: UITextField!
    @IBOutlet weak var textFieldPort: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.textFieldIPAddress.delegate = self
        self.textFieldPort.delegate = self
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textFieldIPAddress.resignFirstResponder()
        textFieldPort.resignFirstResponder()
        return true
    }
    
    @IBAction func buttonSaveAction(_ sender: Any) {
        
        let ipAddress = self.textFieldIPAddress.text
        
        let validIpAddressRegex = "^(([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])\\.){3}([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])$"
        
        let validPortRegex = "^[0-9]{4}$"
        
        if ((ipAddress?.range(of: validIpAddressRegex, options: .regularExpression)) != nil) {
            if((self.textFieldPort.text?.range(of: validPortRegex, options: .regularExpression)) != nil) {
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let vc = storyboard.instantiateViewController(withIdentifier: "RecordViewController") as! RecordViewController
            vc.ipAddress = self.textFieldIPAddress.text!
            vc.portNumber = self.textFieldPort.text!
            navigationController?.pushViewController(vc, animated: true)
            } else {
                let alert = UIAlertController(title: "Alert", message: "Enter valid Port number", preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "OK", style: .default, handler: { action in
                      switch action.style{
                      case .default:
                            print("default")

                      case .cancel:
                            print("cancel")

                      case .destructive:
                            print("destructive")


                }}))
                self.present(alert, animated: true, completion: nil)
            }
        } else {
            let alert = UIAlertController(title: "Alert", message: "Enter valid IP address", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: { action in
                  switch action.style{
                  case .default:
                        print("default")

                  case .cancel:
                        print("cancel")

                  case .destructive:
                        print("destructive")


            }}))
            self.present(alert, animated: true, completion: nil)
        }
    }
}
